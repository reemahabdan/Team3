//
//  ViewController.swift
//  BekeryNano2
//
//  Created by Wafa Alajmi on 22/08/1444 AH.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func BookaSpace(_ sender: UIButton) {
        let PopOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "PopUpID") as! PopUpViewController
        self.addChild(PopOverVC)
        PopOverVC.view.frame = self.view.frame
        self.view.addSubview(PopOverVC.view)
        PopOverVC.didMove(toParent: self)
    }
    
    
    
}
