//
//  PopUpViewController.swift
//  BekeryNano2
//
//  Created by Wafa Alajmi on 28/08/1444 AH.
//

import UIKit

class PopUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func ClosePopUp(_ sender: UIButton) {
        self.view.removeFromSuperview()
    }
    
    
}
