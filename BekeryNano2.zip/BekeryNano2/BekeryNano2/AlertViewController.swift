//
//  AlertViewController.swift
//  BekeryNano2
//
//  Created by Wafa Alajmi on 23/08/1444 AH.
//

import UIKit

class AlertViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func AlertCancel(_ sender: UIButton) {
        showAlertView()

    }
    func showAlertView() {
        let alert = UIAlertController(title: "Cancel booking?", message: "Do you want to cancel your booking", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {
            action in print("Yes Clicked")
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    

}
