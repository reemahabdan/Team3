//
//  CustomTableViewCell.swift
//  bake
//
//  Created by Dana Albabtain on 19/03/2023.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var label: UILabel!

  
    
}
