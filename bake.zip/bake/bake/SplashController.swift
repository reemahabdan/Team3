//
//  SplashController.swift
//  bake
//
//  Created by Dana Albabtain on 19/03/2023.
//

import UIKit

class SplashController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2){
            self.performSegue(withIdentifier: "Open", sender: nil)
            
        }
        
        
        
        
    }
}
