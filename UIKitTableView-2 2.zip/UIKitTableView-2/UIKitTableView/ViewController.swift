//
//  ViewController.swift
//  UIKitTableView
//
//  Created by Lola Almasari on 22/08/1444 AH.
//

import UIKit

class ViewController: UIViewController, UISearchControllerDelegate{
    
    let searchcontroller = UISearchController()
    
    var UIProducts: [Product] = [
        Product(productName: "Babka Dough", productImage: "Babka", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Intermediate"),
        Product(productName: "Cinnamon Rolls", productImage: "CinnamonRoll", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Beginner"),
        Product(productName: "Japanese Bread", productImage: "JapaneseBread", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Advanced"),
        Product(productName: "Banana Bread", productImage: "JapaneseBread", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Intermediate"),
        Product(productName: "Babka Dough", productImage: "Babka", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Intermediate"),
        Product(productName: "Cinnamon Rolls", productImage: "CinnamonRoll", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Beginner"),
        Product(productName: "Japanese Bread", productImage: "JapaneseBread", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Advanced"),
        Product(productName: "Cinnamon Rolls", productImage: "CinnamonRoll", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Beginner"),
        Product(productName: "Banana Bread", productImage: "JapaneseBread", productDate: "19 Feb - 4:00", productDuration: "2h", productLevel: "Intermediate")
    ]
    
    
   
    @IBOutlet var myTableView: UITableView!
    
//    static func fetch_products() -> [Product] {
//        var results:[Product] = []
//        let baseURL = "https://a6bf438f-cd56-4ed1-9647-690231339c09.mock.pstmn.io"
//        let url = URL(string: baseURL+"/getAllcourse")!
//        let task = URLSession.shared.dataTask(with: url){ data,response, error in
//            if let data = data {
//                print(String(data: data, encoding: .utf8),"😀")
//                if let products = try? JSONDecoder().decode([Product].self, from: data) {
//                    results = products
//                    //return products
//                } else {
//                    print("invalid response")
//                    //return []
//                }
//            }else if let error = error {
//                print("HTTP Request Failed \(error)")
//
//            }
//
//        }
//        task.resume()
//
//        return results
//
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        var a =  ViewController.fetch_products()
//        UIProducts = a
        
        
        navigationItem.searchController = searchcontroller
        
        
//        let search = UISearchBar()
//        view.addSubview(search)
      
        myTableView.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        
//    @IBAction func BookaSpace(_ sender: UIButton) {
//            let PopOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "PopUpID") as! PopUpViewController
//            self.addChild(PopOverVC)
//            PopOverVC.view.frame = self.view.frame
//            self.view.addSubview(PopOverVC.view)
//            PopOverVC.didMove(toParent: self)
//        }
        
        
        
    }

    @IBAction func BookaSpase(_ sender: UIButton) {
        let PopOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "PopUpID") as! PopUpViewController
                  self.addChild(PopOverVC)
                  PopOverVC.view.frame = self.view.frame
                  self.view.addSubview(PopOverVC.view)
                  PopOverVC.didMove(toParent: self)
      
    }
}
    
    



    
    
    //TableView
    extension ViewController: UITableViewDataSource, UITableViewDelegate {

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            UIProducts.count
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = myTableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! TableViewCell

               cell.productImage.image = UIImage(named: UIProducts[indexPath.row].productImage)
            cell.productName.text = UIProducts[indexPath.row].productName
            cell.productLevel.text = UIProducts[indexPath.row].productLevel
            cell.productDuration.text = UIProducts[indexPath.row].productDuration
            cell.productDate.text = UIProducts[indexPath.row].productDate


            return cell
        }

        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            120
        }

        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            print("this row \(indexPath.row) is selected")
        }
        

    }

    





extension ViewController: UISearchResultsUpdating{
func updateSearchResults(for searchController: UISearchController) {
    print(#function)
        print(searchController.searchBar.text)
}

}


