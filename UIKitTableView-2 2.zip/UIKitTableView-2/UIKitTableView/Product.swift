//
//  Product.swift
//  UIKitTableView
//
//  Created by Lola Almasari on 22/08/1444 AH.
//

import Foundation

struct Product : Codable{
    var productName: String
    var productImage: String
//    var productDescription: String
    var productDate: String
    var productDuration: String
    var productLevel: String
}
