//
//  ApiController.swift
//  UIKitTableView
//
//  Created by Reema Alhabdan on 20/03/2023.
//

import Foundation

struct courseInfo:  Codable{

  let id: Int
  let title: String
  let level: String
//  let image: String
 // let isComplete: Bool

    
   }

