//
//  TableViewCell.swift
//  UIKitTableView
//
//  Created by Lola Almasari on 22/08/1444 AH.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var productImage: UIImageView!
    @IBOutlet var productName: UILabel!
    @IBOutlet weak var productLevel: UILabel!
    @IBOutlet weak var productDuration: UILabel!
    @IBOutlet weak var productDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        productLevel.backgroundColor = UIColor(named: "Cream")
        productLevel.layer.masksToBounds = true
        productLevel.layer.cornerRadius = 10
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
