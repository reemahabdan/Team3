//
//  PopUpViewController.swift
//  UIKitTableView
//
//  Created by Reema Alhabdan on 22/03/2023.
//

import UIKit

class PopUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func ClosePopUp(_ sender: UIButton) {
        self.view.removeFromSuperview()
    }
    
    
}
