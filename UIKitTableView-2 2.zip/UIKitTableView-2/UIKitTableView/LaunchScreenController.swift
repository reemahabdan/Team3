//
//  SplashController.swift
//  UIKitTableView
//
//  Created by Reema Alhabdan on 22/03/2023.
//

import UIKit

class LaunchScreenController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2){
            self.performSegue(withIdentifier: "Open", sender: nil)
            
        }
        
        
        
        
    }
}
