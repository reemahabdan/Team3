//
//  Dashboard_VC.swift
//  UIKitTableView
//
//  Created by Reema Alhabdan on 22/03/2023.
//

import UIKit
//class Dashboard_VC: UIViewController {
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        let search = UISearchController(searchResultsController: nil)
//        search.searchResultsUpdater = self
//        self.navigationItem.searchController = search
//    }
//   
//    
//    
//}
//extension Dashboard_VC: UISearchResultsUpdating{
//    func updateSearchResults(for searchController: UISearchController) {
//        print(#function)
////        print(UISearchController.searchBar.text)
//    }
//   
//}
